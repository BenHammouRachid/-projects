package hfalbum.uploadPhotos.services.classes;


public class UserResponse {

    public String _id;
    public String name;
    public String facebookId;




}
