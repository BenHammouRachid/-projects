package hfalbum.uploadPhotos.models;
import java.io.Serializable;


public class User implements Serializable{
    public String id ;
    public String name ;
    public String facebookId ;



}
